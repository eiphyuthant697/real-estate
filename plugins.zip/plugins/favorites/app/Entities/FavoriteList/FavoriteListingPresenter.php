<?php
namespace Favorites\Entities\FavoriteList;

/*
* Filters the favorites listing markup
*/
class FavoriteListingPresenter
{
	/**
	* The list options
	* @var object
	*/
	private $list_options;

	/**
	* The Favorite Post ID
	* @var int
	*/
	private $favorite;

	/**
	* The custom markup
	* @var str
	*/
	private $markup;

	/**
	* The return html
	* @var str
	*/
	private $html;

	/**
	* Primary API Method
	* @param str markup
	* @param int favorite
	*/
	public function present($list_options, $markup, $favorite)
	{
		$this->list_options = $list_options;
		$this->markup = $markup;
		$this->favorite = $favorite;

		$this->listingOpening();
		$this->filterMarkup();
		$this->listingClosing();

		return apply_filters('favorites/list/listing/html', $this->html, $this->markup, $this->favorite, $this->list_options);
	}

	/**
	* Create the listing opening
	*/
	private function listingOpening()
	{
		$css = apply_filters('favorites/list/listing/css', $this->list_options->listing_css, $this->list_options);
		$this->html = '<' . $this->list_options->listing_type;
		$this->html .= ' data-postid="' . $this->favorite . '" class="' . $css . '">';
	}

	/**
	* Create the listing closing
	*/
	private function listingClosing()
	{
		$this->html .= '</' . $this->list_options->listing_type . '>';
	}

	/**
	* Filter the markup
	*/
	private function filterMarkup()
	{
		$this->html .= apply_filters('the_content', $this->markup);
		$this->replacePostFields();
		$this->replaceFavoritesFields();
		$this->replaceThumbnails();
		$this->replaceCustomFields();
	}

	/**
	* Replace Post Fields
	*/
	private function replacePostFields()
	{
		$this->html = str_replace('[post_title]', get_the_title($this->favorite), $this->html);
		$this->html = str_replace('[post_permalink]', get_permalink($this->favorite), $this->html);
		$this->html = str_replace('[permalink]', '<a href="' . get_permalink($this->favorite) . '">', $this->html);
		$this->html = str_replace('[/permalink]', '</a>', $this->html);
		$this->html = str_replace('[post_excerpt]', $this->getPostExcerpt(), $this->html);
		$this->html = str_replace('[post_content]', get_the_content($this->favorite), $this->html);
	}

	/**
	* Replace Favorites Fields
	*/
	private function replaceFavoritesFields()
	{
		$this->html = str_replace(
			'[favorites_count]', 
			'<span class="simplefavorites-user-count" data-posttypes="' . $this->list_options->post_types . '" data-siteid="' . $this->list_options->site_id . '">' . get_favorites_count($this->favorite, $this->list_options->site_id) . '</span>', 
			$this->html
		);
		$this->html = str_replace('[favorites_button]', get_favorites_button($this->favorite, $this->list_options->site_id), $this->html);
	}

	/**
	* Replace Thumbnails
	*/
	private function replaceThumbnails()
	{
		$sizes = get_intermediate_image_sizes();
		foreach ( $sizes as $size ){
			if ( strpos($this->html, '[post_thumbnail_' . $size) !== false ){
				$thumb = apply_filters('favorites/list/thumbnail', $this->getThumbnail($size), $this->favorite, $this->list_options->thumbnail_size);
				$this->html = str_replace('[post_thumbnail_' . $size . ']', $thumb, $this->html);
			}
		}
	}

	/**
	* Get a thumbnail
	*/
	private function getThumbnail($size)
	{
		return ( has_post_thumbnail($this->favorite) )	? get_the_post_thumbnail($this->favorite, $size) : ' ';
	}

	/**
	* Replace custom fields
	*/
	private function replaceCustomFields()
	{
		preg_match_all("/\[[^\]]*\]/", $this->html, $out);
		if ( empty($out) ) return;
		foreach($out[0] as $field){
			$field_bracketed = $field;
			$key = str_replace('[', '', $field);
			$key = str_replace('custom_field:', '', $key);
			$key = str_replace(']', '', $key);
			$meta = get_post_meta($this->favorite, $key, true);
			if ( !$meta ) $meta = '';
			if ( is_array($meta) ) $meta = '';
			$this->html = str_replace($field_bracketed, $meta, $this->html);
		}
	}

/**
		 * Social Share links
		 *
		 * @access public
		 * @return void
		 */
		function ccre_post_share() {
			        $cpost_share = get_theme_mod(
			            'real_home_social_share',
			            ['facebook','twitter']
			            //, 'instagram'
			        );
			        //return $csocial_share;
		
			        if ( ! empty( $cpost_share ) ) :
		
			            $cpost_urls = [
			                'facebook'      => 'https://www.facebook.com/sharer/sharer.php?u={url}',
			                'twitter'       => 'https://twitter.com/share?url={url}&text={text}'
			                //'instagram'       => 'https://instagram.com/send?text={text}'
			            ];
		
			            ob_start();
		
			            $pcpost_share ='<ul>';
		
			            foreach ( $cpost_share as $c_post ) :
			                //return $cpost_urls[$c_post] ;
			                if ( isset( $cpost_urls[$c_post] ) ) :
			                    $post_url_link = esc_url( get_the_permalink() );
			                    $post_url = str_replace('{url}',get_permalink($this->favorite),str_replace('{text}',esc_html( get_the_title($this->favorite) ),$cpost_urls[$c_post]));
			                    //return $post_url_link;
			                    $pcpost_share .='<li><a href="' . esc_url( $post_url ) . '" title="' . esc_attr( $c_post ) . '" target=_blank"><label class="screen-reader-text">' . esc_html( $c_post ) . '</label></a></li>';
			                endif;
		
			            endforeach;
		
			            $pcpost_share .='</ul>';
		
			            return $pcpost_share;
		
			            $poutput = ob_get_clean();
		
			            return apply_filters( 'ccre_post_share', $poutput ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		
			        endif;
			    }

	/**
	* Get the post excerpt
	*/
	private function getPostExcerpt()
	{
		$post_id = $this->favorite;
		

    	$the_post = get_post($post_id);
		$the_excerpt = $the_post->post_content;
		$excerpt_length = 12;
		$the_excerpt = strip_tags(strip_shortcodes($the_excerpt));
		$words = explode(' ', $the_excerpt, $excerpt_length + 1);

		if ( count($words) > $excerpt_length ) :
			array_pop($words);
			array_push($words, '…');
			$the_excerpt = implode(' ', $words);
		endif;
		
		$the_excerpt .=	'<div class="post-tags-wrap">';
		$type_terms = wp_get_post_terms($post_id, 'property-type', ['orderby' => 'term_order']);
		if ($type_terms):
			foreach ($type_terms as $type_term):
				$type_link = esc_url(get_term_link($type_term->slug, 'property-type'));
				$type_id = esc_attr($type_term->term_id);
				$type_name = esc_html($type_term->name);
					
				$the_excerpt .=	'<a href='.$type_link.' class="post-tags property-type-'.$type_id.'">'.$type_name.'</a>';
			endforeach;
		endif;

		$status_terms = wp_get_post_terms($post_id, 'property-status', ['orderby' => 'term_order']);
		if ($status_terms):
			foreach ($status_terms as $status_term): 
				$term_link = esc_url(get_term_link($status_term->slug, 'property-status'));
				$term_id = esc_attr($status_term->term_id);
				$term_name = esc_html($status_term->name);
					
				$the_excerpt .=	'<a href='.$term_link.' class="post-tags property-status-'.$term_id.'">'.$term_name.'</a>';
			endforeach;
		endif;
		$the_excerpt .= '</div>';

		$custom_excerpt = '<div class="property-meta entry-meta">';
    	
		$bed_excerpt = get_post_field('cre_property_bedrooms', $this->favorite);
		if ($bed_excerpt)
		$custom_excerpt .= '<div class="fav-meta meta-wrapper"><span class="fmeta-icon"><i class="fa fa-bed"></i></span><span class="meta-value">'. $bed_excerpt .'</span><span class="meta-unit"> bedroom</span></div>';
		$bath_excerpt = get_post_field('cre_property_bathrooms', $this->favorite);
		if ($bath_excerpt)
		$custom_excerpt .= '<div class="fav-meta meta-wrapper"><span class="fmeta-icon"><i class="fa fa-bath"></i></span><span class="meta-value">'.$bath_excerpt .'</span><span class="meta-unit"> bathroom</span></div>';
		$size_excerpt = get_post_field('cre_property_size', $this->favorite);
		$garage_excerpt = get_post_field('cre_property_garage', $this->favorite);
		if ($garage_excerpt)
		$custom_excerpt .= '<div class="fav-meta meta-wrapper"><span class="fmeta-icon"><i class="fa fa-home"></i></span><span class="meta-value">'.$garage_excerpt.'</span><span class="meta-unit"> garage</span></div>';
		if ($size_excerpt)
		$custom_excerpt .= '<div class="fav-meta meta-wrapper"><span class="fmeta-icon"><i class="fa fa-area-chart"></i></span><span class="meta-value">'.$size_excerpt .'</span><span class="meta-unit"> sq ft</span></div>';
		

		$price_excerpt = get_post_field('cre_property_price', $this->favorite);
		$cre_share = $this->ccre_post_share();
		$custom_excerpt .='</div><div class="property-meta-info"><div class="properties-price"><span class="cre-price">$'.$price_excerpt.'</span>';
		
		$price_postfix_excerpt = get_post_field('cre_property_price_postfix', $this->favorite);
		if ($price_postfix_excerpt)
		$custom_excerpt .= '<span class="cre-price-postfix">'.$price_postfix_excerpt.'</span>';
		$custom_excerpt .='</div><div class="properties-contact"><a href="tel:013563184"><i class="fa fa-mobile"></i></a></div><div class="share-section"><a href="javascript:void(0);" target="_self"><i class="fa fa-share-alt"></i></a><div class="block-social-icons social-links">'.$cre_share.'</div></div></div>';
		//$custom_excerpt = get_post_field('cre_property_price', $this->favorite);
		$the_excerpt .= $custom_excerpt;

		return $the_excerpt;
		
	}

}