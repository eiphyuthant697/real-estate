<?php
/**
 * Template part for displaying property post of main detail[property-meta] section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Real_Home
 */

$bedrooms   = get_post_meta( get_the_ID(), 'cre_property_sbedrooms', true );
$mbedrooms   = get_post_meta( get_the_ID(), 'cre_property_mbedrooms', true );
$bathrooms  = get_post_meta( get_the_ID(), 'cre_property_bathrooms', true );
$aircons  = get_post_meta( get_the_ID(), 'cre_property_aircons', true );
$garage     = get_post_meta( get_the_ID(), 'cre_property_garage', true );
$area_size  = get_post_meta( get_the_ID(), 'cre_property_size', true );
$build_year = get_post_meta( get_the_ID(), 'cre_property_year_built', true );
$lot_size           = get_post_meta( get_the_ID(), 'cre_property_lot_size', true );
$type_terms     = wp_get_post_terms( get_the_ID(), 'property-feature', [ 'orderby' => 'term_order' ] );
$gran_terms     = wp_get_post_terms( get_the_ID(), 'property-gran', [ 'orderby' => 'term_order' ] );
 $room_partition  = wp_get_post_terms( get_the_ID(), 'property-room-partition', [ 'orderby' => 'term_order' ] );
$flooring   = wp_get_post_terms( get_the_ID(), 'property-flooring', [ 'orderby' => 'term_order' ] );
$water_type   = wp_get_post_terms( get_the_ID(), 'property-water-system', [ 'orderby' => 'term_order' ] );
$furnishing   = wp_get_post_terms( get_the_ID(), 'property-furnishing', [ 'orderby' => 'term_order' ] );
$electricity   = wp_get_post_terms( get_the_ID(), 'property-electricity', [ 'orderby' => 'term_order' ] );
$bank_installment   = wp_get_post_terms( get_the_ID(), 'property-bank-installment', [ 'orderby' => 'term_order' ] );
$nearby   = get_post_meta( get_the_ID(), 'cre_property_nearby', true );
$living_room   = get_post_meta( get_the_ID(), 'cre_property_living_room', true );

if ( $bedrooms || $bathrooms || $garage || $area_size || $build_year ) :
?>
<div class="property-meta entry-meta single-property-section entry-content">

    <h4><?php esc_html_e( 'Main Detail', 'crucial-real-estate' ); ?></h4>

    <?php if ( $type_terms ) : ?>
        <div class="meta-wrapper">
            <span class="meta-icon">
                <i class="fas fa-house"></i>
            </span>
            <span class="meta-value">
                <?php foreach ( $type_terms as $type_term ) : ?>
					<a href="<?php echo esc_url( get_term_link( $type_term->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $type_term->term_id ); ?>"><?php echo esc_html( $type_term->name ); ?></a>
				<?php endforeach; ?>
            </span>
            <span class="meta-unit"><?php esc_html_e( 'Type', 'crucial-real-estate' ); ?></span>
        </div>
								
	<?php endif; ?>

    <?php if ( $lot_size ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    
                    <i class="fas fa-building"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $lot_size ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'Floor', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>
    
    <?php if ( $area_size ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="fas fa-chart-area"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $area_size ); ?></span>
            <?php if ( $area_size_suffix = get_post_meta( get_the_ID(), 'cre_property_size_postfix', true ) ) : ?>
                <span class="meta-unit"><?php echo esc_html( $area_size_suffix ); ?></span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
        <?php if ( $bedrooms ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="fas fa-bed"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $bedrooms ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'bedroom', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>

    <?php if ( $mbedrooms ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="fas fa-bed"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $mbedrooms ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'master bedrooms', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>

    <?php if ( $bathrooms ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="fas fa-bath"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $bathrooms ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'bathroom', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>
        <?php if ( $living_room ) : ?>
        <div class="meta-wrapper">
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'living room', 'crucial-real-estate' ); ?></span>
            <span class="meta-value"><?php echo esc_html( $living_room ); ?></span>
            
        </div>
    <?php endif; ?>
            <?php if ( $aircons ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <img src="/real-estate/wp-content/uploads/2022/07/icon.png">
                </span>
            <span class="meta-value"><?php echo esc_html( $aircons ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'aircon', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>

    <?php if ( $garage ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="fas fa-home"></i>
                </span>
            <span class="meta-value"><?php echo esc_html( $garage ); ?></span>
            <span class="meta-unit"><?php esc_html_e( 'garage', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>

    

    <?php if ( $build_year ) : ?>
        <div class="meta-wrapper">
                <span class="meta-icon">
                    <i class="far fa-calendar-alt"></i>
                </span>
            <span class="meta-unit"><?php esc_html_e( 'year built', 'crucial-real-estate' ); ?></span>
            <span class="meta-value"><?php echo esc_html( $build_year ); ?></span>

        </div>
    <?php endif; ?>
    <?php if ( $gran_terms ) : ?>
        <div class="meta-wrapper">
            <span class="meta-icon">
                <i class="fas fa-user"></i>
            </span>
            <span class="meta-value">
                <?php foreach ( $gran_terms as $gran_term ) : ?>
					<a href="<?php echo esc_url( get_term_link( $gran_term->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $gran_term->term_id ); ?>"><?php echo esc_html( $gran_term->name ); ?></a>
				<?php endforeach; ?>
            </span>
            <span class="meta-unit"><?php esc_html_e( '', 'crucial-real-estate' ); ?></span>
        </div>
    <?php endif; ?>

        <?php if ( $flooring ) : ?>
        <div class="meta-wrapper">
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'Flooring Type : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $flooring as $flooring_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $flooring_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $flooring_type->term_id ); ?>"><?php echo esc_html( $flooring_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>
            <?php if ( $room_partition ) : ?>
        <div class="meta-wrapper">
            <!--<span class="meta-icon">-->
            <!--    <i class="fas fa-user"></i>-->
            <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'Room Partition : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $room_partition as $room_partition_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $room_partition_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $room_partition_type->term_id ); ?>"><?php echo esc_html( $room_partition_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>
    
                <?php if ( $water_type ) : ?>
        <div class="meta-wrapper">
            <!--<span class="meta-icon">-->
            <!--    <i class="fas fa-user"></i>-->
            <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'WATER SYSTEM TYPE : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $water_type as $water_type_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $water_type_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $water_type_type->term_id ); ?>"><?php echo esc_html( $water_type_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>
    
                    <?php if ( $furnishing ) : ?>
        <div class="meta-wrapper">
            <!--<span class="meta-icon">-->
            <!--    <i class="fas fa-user"></i>-->
            <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'Furnishing : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $furnishing as $furnishing_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $furnishing_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $furnishing_type->term_id ); ?>"><?php echo esc_html( $furnishing_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>
    
                    <?php if ( $electricity ) : ?>
        <div class="meta-wrapper">
            <!--<span class="meta-icon">-->
            <!--    <i class="fas fa-user"></i>-->
            <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'Electricity : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $electricity as $electricity_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $electricity_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $electricity_type->term_id ); ?>"><?php echo esc_html( $electricity_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>
    
                    <?php if ( $bank_installment ) : ?>
        <div class="meta-wrapper">
            <!--<span class="meta-icon">-->
            <!--    <i class="fas fa-user"></i>-->
            <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'Bank Installment : ', 'crucial-real-estate' ); ?></span>
            <span class="meta-value">
                <?php foreach ( $bank_installment as $bank_installment_type ) : ?>
					<a href="<?php echo esc_url( get_term_link( $bank_installment_type->slug, 'property-type' ) ); ?>" class="property-type-<?php echo esc_attr( $bank_installment_type->term_id ); ?>"><?php echo esc_html( $bank_installment_type->name ); ?></a>
				<?php endforeach; ?>
            </span>
            
        </div>
    <?php endif; ?>


                <?php if ( $nearby ) : ?>
        <div class="meta-wrapper">
                <!--<span class="meta-icon">-->
                <!--    <img src="/real-estate/wp-content/uploads/2022/07/flooring.png">-->
                <!--</span>-->
            <span class="meta-unit unit-noicon"><?php esc_html_e( 'NEARBY AMENITIES', 'crucial-real-estate' ); ?></span>
            <span class="meta-value"><?php echo esc_html( $nearby ); ?></span>

        </div>
    <?php endif; ?>
</div><!-- .property-meta entry-meta -->
<?php endif;