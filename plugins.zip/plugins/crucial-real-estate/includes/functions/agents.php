<?php
/**
 * Agent related functions
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! function_exists( 'cre_get_agent_properties_count' ) ) {
	/**
	 * Function: Returns the number of listed properties by an agent.
	 *
	 * @param int $agent_id - Agent ID for properties.
	 * @param string $post_status - Status of properties.
	 *
	 * @return mixed|integer|boolean
	 */
	function cre_get_agent_properties_count( $agent_id, $post_status = '' ) {

		// Return if agent id is empty.
		if ( empty( $agent_id ) ) {
			return false;
		}

		// Prepare query arguments.
		$properties_args = array(
			'post_type'      => 'property',
			'posts_per_page' => - 1,
			'meta_query'     => array(
				array(
					'key'     => 'cre_agents',
					'value'   => absint($agent_id),
					'compare' => '=',
				),
			),
		);

		// If post status is not empty then add it to the query args.
		if ( ! empty( $post_status ) ) {
			$properties_args['post_status'] = $post_status;
		}

		$properties = new WP_Query( $properties_args );
		if ( $properties->have_posts() ) {
			return $properties->found_posts;
		}

		return false;

	}
}