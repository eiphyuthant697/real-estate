<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Real_Home
 */

?>

</div><!-- #content -->

<?php
/**
 * Functions hooked into real_home_footer_before action
 *
 */
do_action( 'real_home_footer_before' );
?>

<footer id="colophon" class="site-footer">

    <?php
    /**
     * Functions hooked into real_home_footer_before action
     *
     */
    do_action( 'real_home_footer_top' );
    ?>

    <?php
    /**
     * Functions hooked into real_home_footer action
     *
     * @hooked real_home_footer_site_info - 10
     */
    do_action( 'real_home_footer' );
    ?>

    <?php
    /**
     * Functions hooked into real_home_footer_before action
     *
     */
    do_action( 'real_home_footer_bottom' );
    ?>

</footer><!-- #colophon -->

<?php
/**
 * Functions hooked into real_home_footer_after action
 *
 * @hooked real_home_footer_back_to_top - 10
 */
do_action( 'real_home_footer_after' );
?>

</div><!-- #page -->


<?php
/**
 * Functions hooked into real_home_body_bottom action
 *
 */
do_action( 'real_home_body_bottom' );
?>

<?php wp_footer(); ?>
<script>
    jQuery(document).ready(function($){
        $('a, img').attr('bis_size','');
        $('a img').attr('style','');
		
        $('select#location_tsp').attr('disabled', 'disabled');
        $('select#location').on('change', function() {
          var selectedParentName =  $(this).children("option:selected").attr('data-id'); //it tracks changes dropdown value
          //console.log(selectedParentName);
          $('select#location_tsp').removeAttr('disabled');
          $.post(
              "/real-estate/wp-content/themes/real-home/child_categories.php", { selectedParent : selectedParentName },
              function(data) {
                $('select#location_tsp').html(data);
                
              }
          );
        });

        // Booking Form
        setTimeout(function() {
              $.post(
                  "/real-estate/wp-content/themes/real-home/parent_type_form.php", { },
                  function(data) {
                      $('select.property-type').html(data);
                  }
              );
        }, 50);
        setTimeout(function() {
            $.post(
                "/real-estate/wp-content/themes/real-home/parent_division_form.php", { },
                function(data) {
                    $('select.property-division').html(data);
                }
            );
        }, 50);

        setTimeout(function() {
            $.post(
                "/real-estate/wp-content/themes/real-home/parent_features_form.php", { },
                function(data) {
                    $('select.property-feature').html(data);
                }
            );
        }, 50);
        
        $('select.property-tsp').attr('disabled', 'disabled');
        $('select.property-division').on('change', function() {
          var selectedParentFormName =  $(this).children("option:selected").attr('data-id'); //it tracks changes dropdown value
          //console.log(selectedParentFormName);
          $('select.property-tsp').removeAttr('disabled');
          $.post(
              "/real-estate/wp-content/themes/real-home/child_categories_form.php", { selectedDivisionName : selectedParentFormName },
              function(data) {
                $('select.property-tsp').html(data);
                
              }
          );
        });
    })
</script>
</body>
</html>
